/* tcpclient.c */

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

int main(int argc, char *argv[]) {

	printf ("This program was called with \"%s\".\n",argv[0]);
	printf ("This program was called with \"%s\".\n",argv[2]);
	int data_length = (*argv[2]);

	char *p;
	int num;

	long conv = strtol(argv[2], &p, 10);
	if (errno != 0 || *p != '\0') {
		printf("Error strtol");
	} else {
		num = conv;
		printf("Data Length = %d\n", num);
	}


	int sock;
	unsigned int send_data[9];
	unsigned char send_data_real[num+6];
	send_data_real[num+7] = '\0';
	//unsigned char send_data_real[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', '\0' };
	printf("Data Length = %d\n", num);





/*=-=-=-=-=-=-=-=-=-=-=-=- Argument Section =-=-=-=-=-=-=-=-=-=-=-*/
		if (argc > 1) {
			for (int count = 1; count < argc; count++) {
	  			printf("argv[%d] = %s\n", count, argv[count]);
			}
		} else {
      		printf("The command had no other arguments.\n");
		}
	
/*=-=-=-=-=-=-=-=-=-=-=-=- Socket Operation =-=-=-=-=-=-=-=-=-=-=-*/
        struct hostent *host;
        struct sockaddr_in server_addr;
        host = gethostbyname(argv[1]);

        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            perror("Socket");
            exit(1);
        }

        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(5000);
        server_addr.sin_addr = *((struct in_addr *)host->h_addr);
        bzero(&(server_addr.sin_zero),8);

        if (connect(sock, (struct sockaddr *)&server_addr,
                    sizeof(struct sockaddr)) == -1)
        {
            perror("Connect");
            exit(1);
        }

        while(1)
        {
/*=-=-=-=-=-=-=-=-=-=-=-=- Binary & Header Processing =-=-=-=-=-=-=-=-=-=-=-*/
time_t rawtime;
struct tm *info;
char buffer[80];

time( &rawtime );

info = localtime( &rawtime );
//printf("Current local time and date: %d", (*info).tm_min);


// Virtual Data (Dummy Data) => For Checking
send_data[0] = 0b00111111;  		// category 8 bit =
send_data[1] = 0b100001;  			// channel 6 bit = 33
send_data[2] = 0b10001;  				// day 5 bit [Need Change][Reserved for checking]
send_data[3] = 0b10011; 				// hour 5 bit [Need Change][Reserved for checking]
send_data[4] = 0b100001; 				// minute 6 bit [Need Change][Reserved for checking]
send_data[5] = 0b111111; 				// second 6 bit [Need Change][Reserved for checking]
send_data[6] = 0b1111111110; 		// milli second 10 bit [Need Change][Reserved for checking]
send_data[7] = 0b1111111001; 		// length of data 10 bit => Tell how many the of the character in the data
send_data[8] = 0b11110110; 			// Data 8 bit
// The result of masking 8 bit is 127, 134, 51, 135, 255, 251, 249
// Notice that the value should be in [0,255]

// Changing Process

// Check with dummy first
send_data[2] = (*info).tm_mday; // day 5 bit [Need Change]
send_data[3] = (*info).tm_hour; // hour 5 bit [Need Change]
send_data[4] = (*info).tm_min; // minute 6 bit [Need Change]
send_data[5] = (*info).tm_sec; // second 6 bit [Need Change]

if( send_data[2] >= 31) {
	send_data[2] = 0b11111;
}

if( send_data[3] >= 31) {
	send_data[3] = 0b11111;
}

if( send_data[4] >= 61) {
	send_data[4] = 0b111111;
}

if( send_data[5] >= 61) {
	send_data[5] = 0b111111;
}
// Checking Process
/*
printf("\n Categoriy : %d", send_data[0]);
printf("\n Channel : %d", send_data[1]);
printf("\n Day : %d", send_data[2]);
printf("\n Hour : %d", send_data[3]);
printf("\n Minute : %d", send_data[4]);
printf("\n Second : %d", send_data[5]);
printf("\n Milli Second : %d", send_data[6]);
printf("\n Length : %d", send_data[7]);

*/
// Data masking 8 bit
send_data_real[0] = send_data[0]; // category 8 bit
send_data_real[1] = (send_data[1]<<2) + (send_data[2]>>3); // channel 6 bit + day 2 upper bit
send_data_real[2] = ((send_data[2]& 0b00111)<<5) + (send_data[3]); // day 3 lower bit + hour 5 bit
send_data_real[3] = (send_data[4]<<2) + (send_data[5]>>4); // minute 6 bit + second 2 upper bit
send_data_real[4] = ((send_data[5]<<2)<<2) + (send_data[6]>>6); // second 4 lower bit + msec 4 upper bit
send_data_real[5] = ((send_data[6]&63)<<2) + ((send_data[7]&768)>>8); // msec 6 lower bit + length 2 upper bit
send_data_real[6] = ((send_data[7]&255)) ; // length 8 bit

// Simulate Data for Testing
for(int k=0;k<num;k++) {
	send_data_real[k+7] = k+65;
}

// Show Data Before Send
/*
printf("\n=-=-=-=-=-=-=-=-=-=-=-=-=\n");
for(int l=0;l<num;l++){
	printf("\n %d : %d", (l),send_data_real[l]);
}
*/
printf("\n send : %s", send_data_real);
send(sock,send_data_real,strlen(send_data_real), 0);
					/* if(send_data[2] == 0b11000000) {
							send_data_real[2] = 67;
					 }
					 if(send_data[3] == 0b11000000) {
							send_data_real[3] = 68;
					 }
					 if(send_data[4] == 0b11000000) {
							&send_data_real[4] = "A";
					 }
					 if(send_data[5] == 0b11000000) {
							&send_data_real[5] = "A";
					 }
					 if(send_data[6] == 0b11000000) {
							&send_data_real[6] = "A";
					 }
					 if(send_data[7] == 0b11000000) {
							&send_data_real[7] = "A";
					 }

					printf("\n send finish : %s", send_data_real);


				  send(sock,send_data_real,strlen(send_data_real), 0);

        }*/}
return 0;
}
