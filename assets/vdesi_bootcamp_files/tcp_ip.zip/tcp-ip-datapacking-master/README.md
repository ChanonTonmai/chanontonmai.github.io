# TCP/IP-datapacking
## For Linux
Client Side 
>> gcc tcpclient.c -o tcpclient
>> ./tcpclient
